let Pchoice = "none";
let Cchoice;
let Cnumchoice;

$(document).ready(function() {
    $("#rock").click(function() {
        $("#Player").removeClass();
        $("#Player").addClass("RockClass");
        Pchoice = "rock";
        console.log("p" + Pchoice);
    });

    $("#paper").click(function() {
        $("#Player").removeClass();
        $("#Player").addClass("PaperClass");
        Pchoice = "paper";
        console.log("p" + Pchoice);
    });

    $("#scissors").click(function() {
        $("#Player").removeClass();
        $("#Player").addClass("ScissorsClass");
        Pchoice = "scissors";
        console.log("p" + Pchoice);
    });

    $("#result").click(function() {

    if(Pchoice == "none"){
            alert("Please make a Move");
        }

    else{
        CnumChoice = Math.floor(Math.random() * 3) + 1;
    
        if (CnumChoice == 1) {
            $("#Computer").addClass("RockClass");
            Cchoice = "rock";
            console.log("C" + Cchoice);
        } 
        else if (CnumChoice == 2) {
            $("#Computer").addClass("PaperClass");
            Cchoice = "paper";
            console.log("C" + Cchoice);
            
        } 
        else if (CnumChoice == 3) {
            $("#Computer").addClass("ScissorsClass");
            Cchoice = "scissors";
            console.log("C" + Cchoice);
        }

        if(Pchoice == Cchoice){
            $("#resultText").text("TIE");
            Pchoice = "none";
         
        }
        else if (Pchoice == "rock"){
            if(Cchoice == "paper"){
                $("#resultText").text("Computer Wins!");
                Pchoice = "none";
            }
            else{
                $("#resultText").text("Player Wins!");
                Pchoice = "none";
            }
        }
        
        else if (Pchoice == "paper"){
            if(Cchoice == "scissors"){
                $("#resultText").text("Computer Wins!");
                Pchoice = "none";
            }
            else{
                $("#resultText").text("Player Wins!");
                Pchoice = "none";
            }
        }

        else if (Pchoice == "scissors"){
            if(Cchoice == "rock"){
                $("#resultText").text("Computer Wins!");
                Pchoice = "none";
            }
            else{
                $("#resultText").text("Player Wins!");
                Pchoice = "none";
            }
        }

        setTimeout(function() {
            $("#Player").removeClass();
            $("#Computer").removeClass();
            $("#resultText").text(" ");
        }, 1000); 
    }






    })
});




